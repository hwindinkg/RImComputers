using System;
using System.Collections.Generic;
using UnityEngine;
using Verse;

namespace RimComputers
{
    /// <summary>
    /// Persistent MonoBehaviour that captures keyboard events every frame.
    ///
    /// Key handling strategy:
    ///   - Printable ASCII (32-126): caught via Input.inputString, but we SKIP any
    ///     char that would duplicate a Ctrl+letter already handled below.
    ///   - Ctrl+letter: caught via GetKeyDown + GetKey(LeftCtrl/RightCtrl).
    ///     The char code sent is the ASCII control code (1-26, e.g. Ctrl+C = 3).
    ///   - Special keys (arrows, F-keys, etc.): GetKeyDown with OC scancodes.
    ///
    /// OC scancode table: https://wiki.vg/Key_Codes  (same as Java KeyEvent VK_*)
    /// OC char codes for Ctrl+X = X - 64  (Ctrl+A=1, Ctrl+B=2 … Ctrl+Z=26)
    /// </summary>
    public class ComputerInputCapture : MonoBehaviour
    {
        public static Dialog_ComputerScreen TargetWindow { get; set; }

        // Tracks which chars came from Ctrl+letter so inputString doesn't double-send them.
        // Unity sometimes puts ASCII ctrl chars (1-26) into inputString too.
        private bool _ctrlKeyHandledThisFrame = false;

        public void Update()
        {
            if (TargetWindow == null) return;

            _ctrlKeyHandledThisFrame = false;

            bool ctrl = Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl);
            bool alt = Input.GetKey(KeyCode.LeftAlt) || Input.GetKey(KeyCode.RightAlt);
            bool shift = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);

            // ── Ctrl+letter ──────────────────────────────────────────────────
            // OC char = ASCII ctrl code (Ctrl+A=1, Ctrl+C=3, Ctrl+D=4, etc.)
            // OC scancode = same as plain letter scancode
            if (ctrl && !alt)
            {
                for (KeyCode kc = KeyCode.A; kc <= KeyCode.Z; kc++)
                {
                    if (Input.GetKeyDown(kc))
                    {
                        int letter = kc - KeyCode.A;          // 0-25
                        double charCode = letter + 1;            // ctrl codes 1-26
                        int scancode = LetterScancode(kc);
                        InputBuffer.EnqueueKeyDown((char)(int)charCode, scancode);
                        InputBuffer.EnqueueKeyUp((char)(int)charCode, scancode);
                        _ctrlKeyHandledThisFrame = true;
                    }
                }
            }

            // ── Printable characters from inputString ────────────────────────
            // Skip if we already handled a Ctrl+letter this frame (avoid duplicates).
            if (!_ctrlKeyHandledThisFrame && Input.inputString.Length > 0)
            {
                foreach (char ch in Input.inputString)
                {
                    // Unity may put ASCII control chars (1-26) in inputString when Ctrl is held.
                    // We already sent these above — skip them.
                    if (ctrl && ch >= 1 && ch <= 26) continue;
                    // Skip DEL (127) — handled below
                    if (ch == 127) continue;

                    int sc = CharToScancode(ch);
                    InputBuffer.EnqueueKeyDown(ch, sc);
                    InputBuffer.EnqueueKeyUp(ch, sc);
                }
            }

            // ── Special / non-printable keys ─────────────────────────────────
            // Scancodes from OC keyboard.lua / Java KeyEvent
            CheckKey(KeyCode.Return, '\n', 28);
            CheckKey(KeyCode.KeypadEnter, '\n', 28);
            CheckKey(KeyCode.Backspace, '\b', 14);
            CheckKey(KeyCode.Escape, '\0', 1);
            CheckKey(KeyCode.Tab, '\t', 15);
            CheckKey(KeyCode.Delete, '\0', 211);
            CheckKey(KeyCode.Insert, '\0', 210);
            CheckKey(KeyCode.UpArrow, '\0', 200);
            CheckKey(KeyCode.DownArrow, '\0', 208);
            CheckKey(KeyCode.LeftArrow, '\0', 203);
            CheckKey(KeyCode.RightArrow, '\0', 205);
            CheckKey(KeyCode.Home, '\0', 199);
            CheckKey(KeyCode.End, '\0', 207);
            CheckKey(KeyCode.PageUp, '\0', 201);
            CheckKey(KeyCode.PageDown, '\0', 209);

            // F-keys (OC scancodes 59-68 for F1-F10, 87-88 for F11-F12)
            CheckKey(KeyCode.F1, '\0', 59);
            CheckKey(KeyCode.F2, '\0', 60);
            CheckKey(KeyCode.F3, '\0', 61);
            CheckKey(KeyCode.F4, '\0', 62);
            CheckKey(KeyCode.F5, '\0', 63);
            CheckKey(KeyCode.F6, '\0', 64);
            CheckKey(KeyCode.F7, '\0', 65);
            CheckKey(KeyCode.F8, '\0', 66);
            CheckKey(KeyCode.F9, '\0', 67);
            CheckKey(KeyCode.F10, '\0', 68);
            CheckKey(KeyCode.F11, '\0', 87);
            CheckKey(KeyCode.F12, '\0', 88);
        }

        private static void CheckKey(KeyCode kc, char ch, int scancode)
        {
            if (Input.GetKeyDown(kc))
            {
                InputBuffer.EnqueueKeyDown(ch, scancode);
                InputBuffer.EnqueueKeyUp(ch, scancode);
            }
        }

        // OC/Java scancodes for letter keys (A=30, B=48, ... Z=44)
        // Full DIK / Java KeyEvent scancode table
        private static readonly int[] LetterScancodes = new int[]
        {
            30, // A
            48, // B
            46, // C
            32, // D
            18, // E
            33, // F
            34, // G
            35, // H
            23, // I
            36, // J
            37, // K
            38, // L
            50, // M
            49, // N
            24, // O
            25, // P
            16, // Q
            19, // R
            31, // S
            20, // T
            22, // U
            47, // V
            17, // W
            45, // X
            21, // Y
            44, // Z
        };

        private static int LetterScancode(KeyCode kc)
        {
            int idx = kc - KeyCode.A;
            if (idx >= 0 && idx < LetterScancodes.Length)
                return LetterScancodes[idx];
            return 0;
        }

        private static int CharToScancode(char ch)
        {
            // Letters
            if (ch >= 'a' && ch <= 'z') return LetterScancodes[ch - 'a'];
            if (ch >= 'A' && ch <= 'Z') return LetterScancodes[ch - 'A'];
            // Digits (1-9=2-10, 0=11)
            if (ch >= '1' && ch <= '9') return 2 + (ch - '1');
            if (ch == '0') return 11;
            // Common punctuation
            if (ch == ' ') return 57;
            if (ch == '\n') return 28;
            if (ch == '\r') return 28;
            if (ch == '\t') return 15;
            if (ch == '-') return 12;
            if (ch == '=') return 13;
            if (ch == '[') return 26;
            if (ch == ']') return 27;
            if (ch == ';') return 39;
            if (ch == '\'') return 40;
            if (ch == '`') return 41;
            if (ch == '\\') return 43;
            if (ch == ',') return 51;
            if (ch == '.') return 52;
            if (ch == '/') return 53;
            return 0;
        }
    }

    /// <summary>
    /// Terminal screen window.
    /// </summary>
    public class Dialog_ComputerScreen : Window
    {
        private readonly Comp_Computer comp;

        private const float BaseCellW = 8f;
        private const float BaseCellH = 15f;
        private const float ToolbarH = 28f;
        private GUIStyle cellStyle;
        private GameObject _captureGo;

        public Dialog_ComputerScreen(Comp_Computer comp)
        {
            this.comp = comp;
            forcePause = false;
            doCloseButton = false;
            doCloseX = false;
            resizeable = true;
            draggable = true;
            onlyOneOfTypeAllowed = true;
            closeOnAccept = false;
            closeOnCancel = false;
            absorbInputAroundWindow = true;
        }

        public override Vector2 InitialSize
        {
            get
            {
                float w = comp.Screen.Width * BaseCellW + 30f;
                float h = comp.Screen.Height * BaseCellH + ToolbarH + 34f;
                return new Vector2(
                    Mathf.Clamp(w, 400f, UI.screenWidth - 40f),
                    Mathf.Clamp(h, 300f, UI.screenHeight - 60f));
            }
        }

        // ════════════════════════════════════════════════════════════════════
        // Lifecycle
        // ════════════════════════════════════════════════════════════════════

        public override void PostOpen()
        {
            base.PostOpen();
            InputBuffer.Clear();
            _captureGo = new GameObject("RimCompInputCapture");
            _captureGo.AddComponent<ComputerInputCapture>();
            UnityEngine.Object.DontDestroyOnLoad(_captureGo);
            ComputerInputCapture.TargetWindow = this;
        }

        public override void PostClose()
        {
            ComputerInputCapture.TargetWindow = null;
            if (_captureGo != null)
                UnityEngine.Object.Destroy(_captureGo);
            base.PostClose();
        }

        // ════════════════════════════════════════════════════════════════════
        // Window draw
        // ════════════════════════════════════════════════════════════════════

        public override void DoWindowContents(Rect inRect)
        {
            EnsureCellStyle();

            float y = inRect.y;
            DrawToolbar(inRect.x, y, inRect.width);
            y += ToolbarH;

            float screenH = inRect.height - ToolbarH;
            var screenRect = new Rect(inRect.x, y, inRect.width, screenH);
            Widgets.DrawBoxSolid(screenRect, Color.black);
            DrawScreen(screenRect);

            if (comp.State == ComputerState.Running)
                DrawCursor(screenRect);
        }

        // ════════════════════════════════════════════════════════════════════
        // Toolbar
        // ════════════════════════════════════════════════════════════════════

        private void DrawToolbar(float x, float y, float w)
        {
            Widgets.DrawBoxSolid(new Rect(x, y, w, ToolbarH - 2f),
                new Color(0.12f, 0.12f, 0.12f));

            Text.Font = GameFont.Tiny;
            Text.Anchor = TextAnchor.MiddleLeft;
            GUI.color = new Color(0.6f, 1f, 0.6f);

            string label = $"  {comp.parent.LabelCap}   [{comp.State}]   " +
                           $"Lua {comp.LuaVerString}   " +
                           $"GPU: {comp.Props.screenWidth}x{comp.Props.screenHeight}";
            Widgets.Label(new Rect(x, y, w - 30f, ToolbarH), label);

            GUI.color = Color.white;
            if (Widgets.ButtonText(new Rect(x + w - 26f, y + 2f, 24f, 24f), "X"))
                Close();

            GUI.color = Color.white;
            Text.Anchor = TextAnchor.UpperLeft;
            Text.Font = GameFont.Small;
        }

        // ════════════════════════════════════════════════════════════════════
        // Screen renderer
        // ════════════════════════════════════════════════════════════════════

        private void DrawScreen(Rect area)
        {
            var buf = comp.Screen;
            if (buf == null) return;

            float cw = area.width / buf.Width;
            float ch = area.height / buf.Height;

            Text.Font = GameFont.Tiny;
            Text.Anchor = TextAnchor.UpperLeft;

            for (int row = 0; row < buf.Height; row++)
                for (int col = 0; col < buf.Width; col++)
                {
                    Color32 bg = buf.GetBG(col, row);
                    Color32 fg = buf.GetFG(col, row);
                    char c = buf.GetChar(col, row);

                    bool isEmpty = (c == ' ' || c == '\0') && bg.r == 0 && bg.g == 0 && bg.b == 0;
                    if (!isEmpty)
                        Widgets.DrawBoxSolid(
                            new Rect(area.x + col * cw, area.y + row * ch, cw + 0.5f, ch + 0.5f),
                            new Color(bg.r / 255f, bg.g / 255f, bg.b / 255f));

                    if (c == ' ' || c == '\0') continue;

                    cellStyle.normal.textColor =
                        new Color(fg.r / 255f, fg.g / 255f, fg.b / 255f);

                    GUI.Label(
                        new Rect(area.x + col * cw, area.y + row * ch, cw, ch + 1f),
                        c.ToString(), cellStyle);
                }

            Text.Anchor = TextAnchor.UpperLeft;
        }

        // ════════════════════════════════════════════════════════════════════
        // Cursor blink
        // ════════════════════════════════════════════════════════════════════

        private float blinkTimer;
        private bool blinkOn = true;

        private void DrawCursor(Rect area)
        {
            blinkTimer += Time.deltaTime;
            if (blinkTimer > 0.5f) { blinkTimer = 0f; blinkOn = !blinkOn; }
            if (!blinkOn) return;

            float cw = area.width / comp.Screen.Width;
            float ch = area.height / comp.Screen.Height;
            int cy = comp.Screen.Height - 1;
            Widgets.DrawBoxSolid(
                new Rect(area.x, area.y + cy * ch, cw, ch),
                new Color(1f, 1f, 1f, 0.8f));
        }

        // ════════════════════════════════════════════════════════════════════
        // Style
        // ════════════════════════════════════════════════════════════════════

        private void EnsureCellStyle()
        {
            if (cellStyle != null) return;
            cellStyle = new GUIStyle(GUI.skin.label)
            {
                wordWrap = false,
                clipping = TextClipping.Overflow,
                padding = new RectOffset(0, 0, 0, 0),
                margin = new RectOffset(0, 0, 0, 0),
            };
            cellStyle.normal.textColor = Color.white;
        }
    }
}